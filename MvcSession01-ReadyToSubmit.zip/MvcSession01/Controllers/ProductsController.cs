using Microsoft.AspNetCore.Mvc;
using MvcSession01.Models;
using MvcSession01.Services;

namespace MvcSession01.Controllers;

public class ProductsController : Controller
{
    private readonly IProductStore _store;
    public ProductsController(IProductStore store) => _store = store;

    // GET /Products or /Products/Index
    public IActionResult Index([FromQuery] ProductSearch filter)
    {
        IEnumerable<Product> products = _store.GetAll();
        if (!string.IsNullOrWhiteSpace(filter.SearchTerm))
            products = products.Where(p => p.Name.Contains(filter.SearchTerm, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(filter.Category))
            products = products.Where(p => p.Category.Equals(filter.Category, StringComparison.OrdinalIgnoreCase));
        if (filter.MinPrice.HasValue) products = products.Where(p => p.Price >= filter.MinPrice.Value);
        if (filter.MaxPrice.HasValue) products = products.Where(p => p.Price <= filter.MaxPrice.Value);
        if (filter.AvailableOnly == true) products = products.Where(p => p.IsAvailable);
        ViewBag.Filter = filter;
        return View(products.ToList());
    }

    // GET /Products/Details/2 — id is bound from the route by convention.
    public IActionResult Details([FromRoute] int id)
    {
        var product = _store.GetById(id);
        return product is null ? NotFound() : View(product);
    }

    [HttpGet]
    public IActionResult Create() => View(new Product());

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create([FromForm] Product product)
    {
        if (!ModelState.IsValid) return View(product);
        _store.Add(product);
        TempData["Success"] = "Product created successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public IActionResult Edit([FromRoute] int id)
    {
        var product = _store.GetById(id);
        return product is null ? NotFound() : View(product);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit([FromRoute] int id, [FromForm] Product product)
    {
        if (id != product.Id) return BadRequest("Route id does not match product id.");
        if (!ModelState.IsValid) return View(product);
        if (!_store.Update(product)) return NotFound();
        TempData["Success"] = "Product updated successfully.";
        return RedirectToAction(nameof(Index));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Delete([FromRoute] int id)
    {
        if (!_store.Delete(id)) return NotFound();
        TempData["Success"] = "Product deleted successfully.";
        return RedirectToAction(nameof(Index));
    }

    // Collection binding from repeated query-string keys: ?ids=1&ids=2
    [HttpGet]
    public IActionResult Compare([FromQuery] List<int> ids)
    {
        var products = _store.GetAll().Where(p => ids.Contains(p.Id)).ToList();
        return View(products);
    }
}
