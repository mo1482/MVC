using Microsoft.AspNetCore.Mvc;

namespace MvcSession01.Controllers;

public class HomeController : Controller
{
    public IActionResult Index() => View();

    public IActionResult About() => View();

    public IActionResult Error() => View();
}
