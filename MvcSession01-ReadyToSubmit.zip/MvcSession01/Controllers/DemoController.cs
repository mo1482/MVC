using Microsoft.AspNetCore.Mvc;
using MvcSession01.Models;
using MvcSession01.Services;

namespace MvcSession01.Controllers;

[Route("demo")]
public class DemoController : Controller
{
    // ViewResult: returns a .cshtml view.
    [HttpGet("")]
    public IActionResult Index() => View();

    // PartialViewResult: returns only a fragment, without the layout.
    [HttpGet("partial")]
    public IActionResult SamplePartial() => PartialView("_DemoMessage", "This HTML fragment was returned by PartialView().");

    // ContentResult: plain text.
    [HttpGet("content")]
    public ContentResult PlainText() => Content("Content() returns plain text.", "text/plain");

    // JsonResult: JSON data.
    [HttpGet("json")]
    public JsonResult JsonSample() => Json(new { Id = 101, Name = "Sample product", Source = "Json()" });

    // RedirectToActionResult: HTTP 302 to another action.
    [HttpGet("redirect-action")]
    public IActionResult RedirectSample() => RedirectToAction("Index", "Products");

    // RedirectResult: HTTP 302 to an arbitrary URL.
    [HttpGet("redirect-url")]
    public IActionResult RedirectUrl() => Redirect("https://learn.microsoft.com/aspnet/core/mvc/overview");

    // NotFound (404), BadRequest (400), Ok (200), and arbitrary StatusCode.
    [HttpGet("status/{code:int}")]
    public IActionResult Status([FromRoute] int code)
    {
        if (code == 404) return NotFound(new { Message = "Demo 404" });
        if (code == 400) return BadRequest(new { Message = "Demo 400" });
        if (code == 200) return Ok(new { Message = "Demo 200" });
        if (code is < 100 or > 599) return BadRequest("HTTP status must be between 100 and 599.");
        return StatusCode(code, new { Message = $"Demo status {code}" });
    }

    // FileResult: downloads a generated text file.
    [HttpGet("download")]
    public FileResult Download()
    {
        var bytes = System.Text.Encoding.UTF8.GetBytes("MVC Session 01 - File() Action Result demonstration.");
        return File(bytes, "text/plain", "mvc-demo.txt");
    }

    // Attribute routing + route constraints: /demo/product/3
    [HttpGet("product/{id:int:min(1)}")]
    public IActionResult ProductById([FromRoute] int id) =>
        Json(new { Id = id, Message = "The int:min(1) route constraint matched." });

    // [FromQuery] and [FromHeader] explicitly select binding sources.
    [HttpGet("binding/sources")]
    public IActionResult BindingSources(
        [FromQuery] string term,
        [FromHeader(Name = "X-Client-Name")] string? clientName = null) =>
        Json(new { QueryTerm = term, HeaderClient = clientName ?? "Header not supplied" });

    // [FromBody] binds JSON request body; [FromServices] resolves a DI service.
    [HttpPost("api/products")]
    public IActionResult CreateFromJson(
        [FromBody] Product product,
        [FromServices] IProductStore store)
    {
        if (!ModelState.IsValid) return ValidationProblem(ModelState);
        var created = store.Add(product);
        return Created($"/Products/Details/{created.Id}", created);
    }

    // [FromForm] binding is demonstrated by Products/Create and Products/Edit.
    // [FromServices] is also shown in this action parameter.
    [HttpGet("binding/service-count")]
    public IActionResult ServiceCount([FromServices] IProductStore store) =>
        Json(new { ProductCount = store.GetAll().Count, InjectedService = nameof(IProductStore) });

    [NonAction]
    public string HelperMethod() => "This public helper is not reachable as an MVC action.";
}
