namespace MvcSession01.Middleware;

public class RequestInfoMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestInfoMiddleware> _logger;

    public RequestInfoMiddleware(RequestDelegate next, ILogger<RequestInfoMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        var requestId = Guid.NewGuid().ToString("N")[..12];
        context.Response.Headers["X-Request-Id"] = requestId;
        _logger.LogInformation("--> {RequestId} {Method} {Path}", requestId, context.Request.Method, context.Request.Path);
        await _next(context); // Pass control to the next middleware.
        _logger.LogInformation("<-- {RequestId} {StatusCode}", requestId, context.Response.StatusCode);
    }
}
