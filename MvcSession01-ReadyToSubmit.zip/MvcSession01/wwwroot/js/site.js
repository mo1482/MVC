// Small client-side enhancement. Server-side ModelState validation remains authoritative.
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('form[onsubmit]').forEach(form => {
        form.addEventListener('submit', event => {
            if (form.dataset.confirmed === 'true') return;
        });
    });
});
