using MvcSession01.Middleware;
using MvcSession01.Services;

var builder = WebApplication.CreateBuilder(args);

// MVC services must be registered before Build().
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<IProductStore, InMemoryProductStore>();

var app = builder.Build();

// Middleware order matters: the exception handler wraps everything after it.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // Static files are served without reaching MVC.
app.UseMiddleware<RequestInfoMiddleware>(); // Custom Use-style middleware.

app.UseRouting();
app.UseAuthorization();

// Map creates a separate pipeline branch and demonstrates short-circuiting.
app.Map("/pipeline", branch =>
{
    branch.Use(async (context, next) =>
    {
        context.Response.Headers["X-Pipeline-Branch"] = "Map branch";
        await next();
    });
    branch.Run(async context =>
    {
        context.Response.ContentType = "text/plain; charset=utf-8";
        await context.Response.WriteAsync("You are inside the /pipeline Map branch.\nThis branch ends with Run() and does not reach MVC.");
    });
});

// Specific route must be registered before the general conventional route.
app.MapControllerRoute(
    name: "featured-products",
    pattern: "shop/{id:int}",
    defaults: new { controller = "Products", action = "Details" });

// Default conventional route: /{controller=Home}/{action=Index}/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
