using System.ComponentModel.DataAnnotations;

namespace MvcSession01.Models;

public class Product
{
    public int Id { get; set; }

    [Required, StringLength(80, MinimumLength = 2)]
    [Display(Name = "Product name")]
    public string Name { get; set; } = string.Empty;

    [Required, StringLength(500, MinimumLength = 5)]
    public string Description { get; set; } = string.Empty;

    [Range(0.01, 1_000_000)]
    public decimal Price { get; set; }

    [Range(0, 100_000)]
    [Display(Name = "Stock quantity")]
    public int Stock { get; set; }

    [Required, StringLength(40)]
    public string Category { get; set; } = string.Empty;

    [Display(Name = "Available")]
    public bool IsAvailable { get; set; } = true;
}
