using System.ComponentModel.DataAnnotations;

namespace MvcSession01.Models;

public class ProductSearch
{
    public string? SearchTerm { get; set; }
    public string? Category { get; set; }
    [Range(0, 1_000_000)] public decimal? MinPrice { get; set; }
    [Range(0, 1_000_000)] public decimal? MaxPrice { get; set; }
    public bool? AvailableOnly { get; set; }
}
