# Route MVC Lab — Session 01

A complete ASP.NET Core MVC learning project covering the concepts in the supplied **MVC Session 01** material: MVC architecture, actions and action results, middleware, routing, model binding, and validation.

## Requirements

- .NET 8 SDK (or a newer SDK capable of targeting `net8.0`)
- Visual Studio 2022, VS Code, or Rider (optional)
- A modern browser

## Run the project

Open a terminal in the folder that contains `MvcSession01.csproj` and run:

```bash
dotnet restore
dotnet run
```

Open the local URL printed by the .NET CLI. The project has no external NuGet package dependencies. Product data is stored in memory, so it resets when the application restarts.

## Project structure

```text
MvcSession01/
├── Controllers/
│   ├── HomeController.cs
│   ├── ProductsController.cs
│   └── DemoController.cs
├── Middleware/
│   └── RequestInfoMiddleware.cs
├── Models/
│   ├── Product.cs
│   └── ProductSearch.cs
├── Services/
│   ├── IProductStore.cs
│   └── InMemoryProductStore.cs
├── Views/
│   ├── Home/
│   ├── Products/
│   ├── Demo/
│   └── Shared/
├── wwwroot/
│   ├── css/site.css
│   └── js/site.js
├── Program.cs
└── MvcSession01.csproj
```

## Feature checklist mapped to the lecture

### 1. MVC — Model, View, Controller

- `Models/Product.cs`: product data and Data Annotations validation rules.
- `Views/`: Razor `.cshtml` UI; shared layout in `Views/Shared/_Layout.cshtml`.
- `Controllers/ProductsController.cs`: receives requests, uses the store, and returns views/results.
- `Program.cs`: registers MVC with `AddControllersWithViews()` before `Build()`.
- Product request flow: browser → routing → `ProductsController` → `IProductStore` → Razor view → HTML.

### 2. Actions and Action Results

Open `/demo` to try each live action:

| Lecture result/helper | Demo URL |
|---|---|
| `View()` / `ViewResult` | `/demo` |
| `PartialView()` / `PartialViewResult` | `/demo/partial` |
| `Content()` / `ContentResult` | `/demo/content` |
| `Json()` / `JsonResult` | `/demo/json` |
| `RedirectToAction()` | `/demo/redirect-action` |
| `Redirect()` | `/demo/redirect-url` |
| `NotFound()` | `/demo/status/404` |
| `BadRequest()` | `/demo/status/400` |
| `Ok()` | `/demo/status/200` |
| `StatusCode(code)` | `/demo/status/418` |
| `File(bytes, contentType, fileName)` | `/demo/download` |

`ProductsController` also demonstrates `IActionResult` where a condition can return a view, redirect, bad request, or not found. `DemoController.HelperMethod()` is public but marked `[NonAction]`, so it is not exposed as an action. Actions are public instance methods; HTTP attributes distinguish GET and POST handlers.

### 3. Middleware and request pipeline

`Program.cs` demonstrates the ordering and purpose of middleware:

1. Exception handling / developer exception page.
2. HTTPS redirection and HSTS (outside Development).
3. Static files.
4. Custom `RequestInfoMiddleware`.
5. Routing.
6. Authorization.
7. Endpoint route mappings.

- `RequestInfoMiddleware` logs before and after the next middleware, adds `X-Request-Id`, and calls `await _next(context)` — a custom `Use`-style middleware.
- `app.Map("/pipeline", ...)` creates a path branch and sets a response header.
- `branch.Run(...)` is terminal and ends that branch without reaching MVC.
- Open `/pipeline` to see the branch response.

### 4. Routing

- Conventional default route: `/{controller=Home}/{action=Index}/{id?}`.
- Specific conventional route registered first: `/shop/{id:int}` maps to `Products/Details`.
- Attribute routing: `DemoController` uses `[Route("demo")]` and HTTP method templates.
- Route constraints: `/demo/product/{id:int:min(1)}` and `/demo/status/{code:int}`.
- A route constraint mismatch does not select that endpoint (normally resulting in 404).

Try `/Products`, `/Products/Details/2`, `/shop/2`, `/demo/product/3`, and `/demo/product/abc`.

### 5. Model Binding and Validation

| Binding source | Where demonstrated |
|---|---|
| `[FromRoute]` | Product details/edit/delete IDs and demo route IDs |
| `[FromQuery]` | Product search filters and `/demo/binding/sources?term=keyboard` |
| `[FromForm]` | Product Create and Edit forms |
| `[FromHeader]` | `/demo/binding/sources` reads `X-Client-Name` |
| `[FromBody]` | `POST /demo/api/products` reads JSON |
| `[FromServices]` | Demo actions resolve `IProductStore` from dependency injection |

- Complex type binding: the `ProductSearch` and `Product` parameters are populated by property names.
- Collection binding: `/Products/Compare?ids=1&ids=2` binds repeated query values to `List<int>`.
- Conversion/validation errors are recorded in `ModelState`; invalid create/edit forms are redisplayed instead of saved.
- `Product` uses `[Required]`, `[StringLength]`, and `[Range]` validation attributes.

Example JSON API request:

```bash
curl -X POST https://localhost:5001/demo/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"USB Charger","description":"Fast USB-C charger","price":350,"stock":10,"category":"Accessories","isAvailable":true}'
```

Use the actual HTTPS or HTTP port printed by `dotnet run`. A successful request returns `201 Created`; invalid model data returns validation details.

## Main pages

- `/` — project overview and MVC request flow.
- `/Products` — product catalog, search and filtering.
- `/Products/Create` — create form and validation.
- `/Products/Edit/1` — edit form and validation.
- `/demo` — action results, routing and binding examples.
- `/pipeline` — Map/Run middleware branch.

## Notes

- This is a teaching/demo application, not a production inventory system.
- The store is intentionally in-memory to keep the project focused on Session 01 MVC concepts; data is reset at restart.
- Client-side validation scripts are referenced from public CDNs. Server-side Data Annotations and `ModelState.IsValid` validation work independently of those scripts.
- No database, authentication, or authorization policy was specified in the supplied Session 01 material, so none is added as an invented requirement.
