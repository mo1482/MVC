using MvcSession01.Models;

namespace MvcSession01.Services;

public class InMemoryProductStore : IProductStore
{
    private readonly object _lock = new();
    private readonly List<Product> _products =
    [
        new() { Id = 1, Name = "Mechanical Keyboard", Description = "A durable mechanical keyboard with tactile switches.", Price = 1450, Stock = 12, Category = "Accessories", IsAvailable = true },
        new() { Id = 2, Name = "Wireless Mouse", Description = "Ergonomic wireless mouse with adjustable sensitivity.", Price = 650, Stock = 25, Category = "Accessories", IsAvailable = true },
        new() { Id = 3, Name = "27-inch Monitor", Description = "Full HD monitor suitable for work and entertainment.", Price = 5200, Stock = 0, Category = "Displays", IsAvailable = false },
        new() { Id = 4, Name = "USB-C Hub", Description = "Multiport USB-C hub with HDMI and USB connections.", Price = 890, Stock = 8, Category = "Accessories", IsAvailable = true }
    ];
    private int _nextId = 5;

    public IReadOnlyList<Product> GetAll()
    {
        lock (_lock) return _products.Select(Clone).ToList();
    }

    public Product? GetById(int id)
    {
        lock (_lock)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            return product is null ? null : Clone(product);
        }
    }

    public Product Add(Product product)
    {
        lock (_lock)
        {
            var copy = Clone(product);
            copy.Id = _nextId++;
            _products.Add(copy);
            return Clone(copy);
        }
    }

    public bool Update(Product product)
    {
        lock (_lock)
        {
            var existing = _products.FirstOrDefault(p => p.Id == product.Id);
            if (existing is null) return false;
            existing.Name = product.Name;
            existing.Description = product.Description;
            existing.Price = product.Price;
            existing.Stock = product.Stock;
            existing.Category = product.Category;
            existing.IsAvailable = product.IsAvailable;
            return true;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock)
        {
            var product = _products.FirstOrDefault(p => p.Id == id);
            return product is not null && _products.Remove(product);
        }
    }

    private static Product Clone(Product p) => new()
    {
        Id = p.Id, Name = p.Name, Description = p.Description, Price = p.Price,
        Stock = p.Stock, Category = p.Category, IsAvailable = p.IsAvailable
    };
}
